//
//  User.swift
//  RandomChat
//
//  Created by Lương Linh on 25/5/18.
//  Copyright © 2018 toantt. All rights reserved.
//

import UIKit

class User: NSObject {
    var name:String?
}
